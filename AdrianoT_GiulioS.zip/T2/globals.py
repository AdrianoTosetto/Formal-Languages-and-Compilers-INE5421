'''
	Autoria: Adriano Tosetto, Giulio Simão
'''

class Globals:
    traversal = []
    grammars = []
    grammar_count = 1
    selected = None
    m = None
